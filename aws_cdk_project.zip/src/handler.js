"use strict";
exports.__esModule = true;
var wikiApi_1 = require("./wikiApi");
var wiki = new wikiApi_1.WikiApi('en', 'DoceboLMS');
wiki.getConvertedWikiData();
//# sourceMappingURL=handler.js.map