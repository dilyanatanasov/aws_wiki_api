"use strict";
exports.__esModule = true;
var wikiApi_1 = require("./wikiApi");
exports.handler = function (event, context, callback) {
    var wiki = new wikiApi_1.WikiApi(event.language, event.pageName);
    callback(wiki.getConvertedWikiData());
};
//# sourceMappingURL=handler.js.map