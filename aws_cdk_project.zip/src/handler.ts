import {WikiApi} from './wikiApi';

exports.handler = (event: any, context: any, callback: any) => {
  const wiki = new WikiApi(event.language, event.pageName);
  callback(wiki.getConvertedWikiData());
}
