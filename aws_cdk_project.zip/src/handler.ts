import {WikiApi} from './wikiApi';

const wiki = new WikiApi('en','DoceboLMS');
wiki.getConvertedWikiData();